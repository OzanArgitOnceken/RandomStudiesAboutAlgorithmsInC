#include<stdio.h>
#include<stdlib.h>
#define pr printf
#define sc scanf

typedef struct tre tr;
typedef struct tre {
	int data;
	tr* left;
	tr* right;
};
void addlist(int,tr*);
void search(int ,tr*);
void main()
{
	int cho=1;
	tr *start=NULL;
	while(cho)
	{
		pr("Enter Num:\n");
		sc("%d",&cho);
		addlist(cho,start);
	}
	cho=1;
	while(cho)
	{
		pr("Serch Num:\n");
		sc("%d",&cho);
		search(cho,start);
	}
}
void addlist(int x,tr* start)
{
		tr* eklenecek=(tr*)malloc(sizeof(tr));
		eklenecek->data=x;
		eklenecek->left=NULL;
		eklenecek->right=NULL;
		tr* temp;
		if(start==NULL)
		{
			start=eklenecek;
		}
		else
		{
			temp=start;
			while(temp!=NULL)
			{
				if(x>temp->data)
				{
					temp=temp->right;
				}
				else
				{
					temp=temp->left;
				}
			temp=eklenecek;
			}
		}
}
void search(int x,tr* start)
{
	if(x=start->data)
	{
		pr("%d is fined\n",start->data);
	}
	else
	{
		tr* temp;
		temp=start;
		while (temp->data!=x)
		{
			pr("\n\n\n%d\n\n\n",temp->data);
			if(x>temp->data)
			{
				temp=temp->right;
				pr("BIGGER\n");
			}
			else
			{
				temp=temp->left;
				pr("SMALLER\n");
			}
			
		}
		
			pr("\n\n\n!!!!!!!!WE FOUND IT!!!!!!\n\n\n\n\n%d\n\n\n",temp->data);
		
	}
	
}
