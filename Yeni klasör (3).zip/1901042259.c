#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#define PI 3.14159265358979323846//�t is pi number 
/*
	Hocam iyi ak�amlar kodumu bilgisayar�m nedeniyle genelde windows �zerinde yaz�yorum okul zaman� lab 
bilgisayarlar�nda test etme �ans�m oluyordu fakat art�k okul d��� bi tan�d���ma test ettiriyorum (�dev konusunda hassas
oldu�um i�in)�yle oldu�u i�in 1 defa test ettirebildim ve kod windowsta s�k�nt�s�z �al���rken ubuntuda s�k�nt� verebiliyormu�
e�er �al��mazsa windowsta denemenizi rica ederim ��nk� windowsta s�k�nt�s�z �al���yor
*/
typedef struct points{//a point struct includes x coordinate and y coordinate
	double x;
	double y;
}point;
typedef struct liness{//line struct includes 2 point struct
	point poi1;
	point poi2;
}lines;
typedef struct polygons{//a polygon includes point struct array and line array
	point poi[100];//i will use point array if I need
	lines lin[100];//I will use line array if I need
}poly;
int comMenu(char[]);
int getCommand(char [],char []);
int arrhold(char[]);
void apoline(lines*,point[],char []);
void apPoint(point*,char []);
void apPoly(poly* ,point [],lines[],char []);
double angle(lines,lines);
double dist(point[],int,int);
double distLine(point,lines);
double leng(poly );
double area(poly);
void main()
{
	int arrnum;//it is array number which will decide where I should put the value
	char line[100];//it is not line struct it is just a linefor read from the txt
	FILE*com=fopen("commands.txt","r");//open commands.txt and read it
	point myPoint[100];//it is where I put points
	lines myLine[100];//it is where I put lines
	poly poli[2];//it is where I put polygons//sdfsdfsdfsdfsdfsdfsd
	char command[100];//command will hold the command(if line is:L1 L2 P4//hello, command is L1 L2 P4)
	do{//here I'm reading and taking datas while it is not action
		fgets(line,100,com);//get the whole line
		getCommand(command,line);//put the necessary part in command
		if(!strcmp(line,"actions\n"))//If it is action break the while
			break;
		if(!strcmp(command,"data"))
		{
			fgets(line,100,com);
			int how;
			sscanf(line,"%d",&how);
		//	data=(double*)malloc(sizeof(double)*how);
		}
		else
		{
			int whCom=comMenu(command);//whCom means which order text sad
			if(whCom==1)
			{
				char*asd;
				char smth[100];
				char *stdif;
				strcpy(smth,command);
				asd=strtok(smth," ");
				while(asd!=NULL)
				{
					stdif=asd;
					asd=strtok(NULL," ");
				}//crumble the command 
				sscanf(stdif+2,"%d",&arrnum);//which polygon we will make appointment of data
				apPoly(&poli[arrnum],myPoint,myLine,command);//put datas in polygon
			}
			else if(whCom==2)
			{
				arrnum=arrhold(command);
				apoline(&myLine[arrnum],myPoint,command);//make appointments of the Line
			}
			else if(whCom==3)
			{
				arrnum=arrhold(command);
				apPoint(&myPoint[arrnum],command);//make appointment of point
			}
		}
	}while(1);
	char name[100];//it will hold the new txt name
	fgets(line,100,com);
	getCommand(command,line);
	strcpy(name,command);//put the txt name correctly
	FILE*answer=fopen(name,"w");//open and write in it
	while(!feof(com))//read commends until it ends
	{
		fgets(line,100,com);
		char temp[100];
		char *sptr;//some pointer
		strcpy(temp,line);
		sptr=strtok(temp," ");
		if(!strcmp(sptr,"Distance"))
		{
			sptr=strtok(NULL," ");
			int p1;
			sscanf(sptr+1,"%d",&p1);
			sptr=strtok(NULL,"  ");
			int p2;
			sscanf(sptr+1,"%d",&p2);//I am putting which distances I will calculate in p1 and p2
			if(sptr[0]=='P')
				fprintf(answer,"Distance (P%d,P%d)=%lf\n",p1,p2,dist(myPoint,p1,p2));//now we are printing it
			else
				fprintf(answer,"Distance (P%d,L%d)=%lf\n",p1,p2,distLine(myPoint[p1],myLine[p2]));//now we are printing it
		}
		else if(!strcmp(sptr,"Angle"))
		{
			sptr=strtok(NULL," ");
			int p1;
			sscanf(sptr+1,"%d",&p1);
			sptr=strtok(NULL," ");
			int p2;
			sscanf(sptr+1,"%d",&p2);//it is the same method of distance
			fprintf(answer,"Angle(L%d,L%d)=%lf\n",p1,p2,angle(myLine[p1],myLine[p2]));
		}
		else if(!strcmp(sptr,"Length"))
		{
			sptr=strtok(NULL," ");
			int p1;
			sscanf(sptr+2,"%d",&p1);
			fprintf(answer,"Length(P%d)=%lf\n",p1,leng(poli[p1]));
		}
		else if(!strcmp(sptr,"Area"))
		{
			sptr=strtok(NULL," ");
			int p1;
			sscanf(sptr+2,"%d",&p1);
			fprintf(answer,"Area(P%d)=%lf\n",p1,area(poli[p1]));
		}
	}
	fclose(answer);//close the txt's
	fclose(com);
}
int getCommand(char command[],char line[])
{
	if(line[0]=='\n')
		return 6;
		int i=0;//in here I made command array empty
		for(;i<100;i++)
			command[i]='\0';
		i=0;
		do{
			if(line[i]!='\n'&&line[i]!='/')
			{
				command[i]=line[i];
				i++;
			}
		}while(line[i]!='/'&&line[i]!='\n');//put letters in command while it is not / or \n
}
int comMenu(char com[])
{
	char *str;
	char temp[100];
	strcpy(temp,com);
	str=strtok(temp," ");
	while(str!=NULL)
	{
		strcpy(temp,str);
		str=strtok(NULL," ");
	}
	if(temp[1]=='G')//if 2nd letter is g it means it is a polygon
		return 1;
	else
	{
		if(temp[0]=='L')//if first letter is L it is line
			return 2;
		else//else it is a point
			return 3;
	}
}
void apPoint(point* po,char com[])
{
	char *ptr;
	char temp[100];
	strcpy(temp,com);
	ptr=strtok(temp," ");
	sscanf(ptr,"%lf",&po->x);//make it double and put in point x
	ptr=strtok(NULL," ");
	sscanf(ptr,"%lf",&po->y);//make it double and put in point y
}
void apoline(lines* line,point poi[],char com[])
{
	char *ptr;
	char sth[100];
	strcpy(sth,com);
	ptr=strtok(sth," ");
	int which;
	sscanf(ptr+1,"%d",&which);//understand which point it is 
	line->poi1=poi[which];//put that point in line's point 1
	ptr=strtok(NULL," ");
	sscanf(ptr+1,"%d",&which);
	line->poi2=poi[which];//make the same thing again
}
void apPoly(poly* poli,point point[],lines lines[],char com[])
{
	char *ptr;
	char temp[100];
	strcpy(temp,com);
	ptr=strtok(temp," ");
	int i=0,which;
	if(ptr[0]=='P')//if it is point
	{
		while(ptr[1]!='G')//while we are reading points
		{
			sscanf(ptr+1,"%d",&which);
			poli->poi[i]=point[which];//put the point in polygon's point 
			ptr=strtok(NULL," ");
			i++;
		}//we are done here
		poli->poi[i].x=-1,poli->poi[i].y=-1;//it is for determine the finish 
		poli->lin[0].poi1.x=-10;//it is for determine that is not includes lines
	}
	else
	{
		while(ptr[1]!='G')
		{
			sscanf(ptr+1,"%d",&which);
			poli->lin[i]=lines[which];
			ptr=strtok(NULL," ");
			i++;
		}//same method at putting points
		poli->lin[i].poi1.x=-1,poli->lin[i].poi1.y=-1;//it is for determine the finish  
		poli->poi[0].x=-1;//it is for determine that is not includes points
	}
}
int arrhold(char com[])//it makes line [34] fulfilled(it only says we should put at 34(34 is an example))
{
	int where;//it is an integer which will hold where we will put it 
	char temp[100];
	char *ptr;
	strcpy(temp,com);
	ptr=strtok(temp," ");
	ptr=strtok(NULL," ");
	ptr=strtok(NULL," ");//I make all commend line lokks like L34
	sscanf(ptr+1,"%d",&where);//here I'm putting 34 in where instead of L34
	return where;
}

double dist(point points[],int p1,int p2)
{	//it is all math
	return sqrt((points[p1].x-points[p2].x)*(points[p1].x-points[p2].x)+(points[p1].y-points[p2].y)*(points[p1].y-points[p2].y));
}
double distLine(point poi,lines li)
{
	double tx=1,ty=1,tnx,tny;
	ty*=(li.poi2.x-li.poi1.x);//it is a mathematical formula
	tny=-li.poi2.y;//which is (y-y2/x-x2)=(y2-y1/x2-x1)
	tny*=(li.poi2.x-li.poi1.x);
	tx*=(li.poi2.y-li.poi1.y);
	tnx=-li.poi1.x;
	tnx*=(li.poi2.y-li.poi1.y);
	return (double)abs((tx*poi.x+ty*poi.y+tnx+tny)/sqrt(tx*tx+ty*ty));
}
double angle(lines li1,lines li2)
{//it is all mathematical 
	double li1x=(double)abs(li1.poi1.x-li1.poi2.x);//I'm calcu�ating the angle with vectors
	double li1y=(double)abs(li1.poi1.y-li1.poi2.y);
	double li2x=(double)abs(li2.poi1.x-li2.poi2.x);
	double li2y=(double)abs(li2.poi1.y-li2.poi2.y);
	double sq1=sqrt(li1x*li1x+li1y*li1y);
	double sq2=sqrt(li2x*li2x+li2y*li2y);
	double crosab=(li1x*li2x)+(li1y*li2y);
	double cosin=(crosab/(sq1*sq2));
	return (180*acos(cosin)/PI);
}
double leng(poly pol)
{
	int i=0;
	double sum=0;
	if(!(pol.lin[0].poi1.x<0))//if it is line
	{
		while(pol.lin[i].poi1.x>=0)
		{
			double lenx=(double)abs(pol.lin[i].poi1.x-pol.lin[i].poi2.x);
			double leny=(double)abs(pol.lin[i].poi1.y-pol.lin[i].poi2.y);
			sum+=sqrt((lenx*lenx)+(leny*leny));
			i++;
		}
	}
	else 
	{
		while(pol.poi[i].x>=0)
		{	
			double lenx;
			double leny;
			if(pol.poi[i+1].x<0)//if the next point is not appointed calculate distance between last point with first
			{	
				lenx=pol.poi[i].x-pol.poi[0].x;
				leny=pol.poi[i].y-pol.poi[0].y;
			}
			else
			{
				lenx=pol.poi[i].x-pol.poi[i+1].x;
				leny=pol.poi[i].y-pol.poi[i+1].y;
			}
			sum+=sqrt(lenx*lenx+leny*leny);
			i++;
		}
	}
	return sum;
}
double area(poly pol)
{
	int i=0;
	double sum=0;
	if((pol.lin[0].poi1.x<0))//if it is point
	{
		while(pol.poi[i].x>=0)
		{//it is all mathematical calculations
			if(pol.poi[i+1].x<0)
				sum+=((pol.poi[i].x*pol.poi[0].y)-(pol.poi[i].y*pol.poi[0].x))/2;
			else
				sum+=((pol.poi[i].x*pol.poi[i+1].y)-(pol.poi[i].y*pol.poi[i+1].x))/2;
			i++;
		}
	}
	else
	{
		while(pol.lin[i].poi1.x>=0)
		{//it is all mathematical
			sum+=((pol.lin[i].poi1.x*pol.lin[i].poi2.y)-(pol.lin[i].poi1.y*pol.lin[i].poi2.x))/2;
			i++;//but the difference between point calculation every line inludes first and seccond point in it
		}
	}
	return sum;
}
