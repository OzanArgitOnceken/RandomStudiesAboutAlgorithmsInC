#include <stdio.h>
#include <conio.h>
#define DEBUG 0
void yazdir(int dizi[][10],int gun);
int bittimi(int dizi[][10],int gun);
void sirala(int dizi[3]);
int main()
{
	// ***** 1. a�ama - De�er al�m�
	printf("En basta acik olan 3 lambanin numarasini\narada bosluk olmadan giriniz:");
	char acik[5]= {};
	scanf("%s",acik);
	fflush(stdin);
	int aciklamba[3];
//Eger kucukten buyuge (orn. 8910) giri� yap�lacaksa sadece 3.indistekinin 0 olup olmadigina bakmak yeter.
//Genel olarak ise 1098\0 ya da 123\0 seklinde olabilir.
	int i,j=2;
	for (i=3; i>=0; i--) //10 girisini algilamak icin sondan baslayalim
	{
		if(acik[i]=='\0') continue;        // *****   // ***** 2. a�ama - Baslang�� durumunun yazd�r�lmas�
		if(acik[i]=='0')
		{
			aciklamba[j]=10;
			j--;
			i--;
		}
		else
		{
			aciklamba[j]=(int)acik[i]-(int)'0';
			j--;
		}
	}
	sirala(aciklamba);
	printf("Girmis oldugunuz degerler: %d %d %d\n", aciklamba[0],aciklamba[1],aciklamba[2]);
	if(!DEBUG)
	{
		printf("Devam etmek icin bir tusa basiniz...");
		getch();
		system("cls");
	}

	int sistem[8][10]= {}; //acik olmayan 7 lamba oldugu icin maksimum 7 ek gun gerekir.
	int gun=0;
	for(i=0; i<3; i++)
	{
		sistem[gun][ aciklamba[i] -1 ]=1; // acik lambalar sisteme islendi
	}
	if(!DEBUG)printf("1.gunun basinda acik olan lambalar su sekildedir.\n\n");
	yazdir(sistem,gun);
	if(!DEBUG)
	{
		printf("Devam etmek icin bir tusa basiniz...");        // *****   // ***** 3. a�ama - Gunlerin yazd�r�lmas�
		getch();
	}
	for(gun=1; 1 ; gun++)
	{
		for(i=0; i<10; i++)
		{
			if(sistem[gun-1][i]==1)
			{
				if(i!=0) sistem[gun][i-1]=1;
				sistem[gun][i]=1;
				if(i!=9)sistem[gun][i+1]=1;
			}
		}
		if(!DEBUG)
		{
			system("cls");
			printf("%d. gunun sonunda acik olan lambalar su sekildedir.\n\n",gun );
		}
		yazdir(sistem,gun);
		if(bittimi(sistem, gun)==1)    break;
		else
		{
			if(!DEBUG)
			{
				printf("Bir sonraki gun icin bir tusa basiniz...");
				getch();
			}
		}
	}
	printf("Tum lambalar acilmistir. Gun aydin!");
	return 0;
}

void yazdir(int dizi[][10],int gun)
{
	int i;
	if(!DEBUG)for(i=0; i<10; i++)  printf(" LB%d",i+1);
	if(!DEBUG)printf("\n");
	for(i=0; i<10; i++)  printf("  %d ",dizi[gun][i]);
	printf("\n");
}
int bittimi(int dizi[][10],int gun)
{
	int  i;
	for(i=0; i<10; i++)   
	if(dizi[gun][i]==0) return 0;
	return 1;
}
void sirala(int dizi[3])
{
	int t;  //az eleman oldugu icin kabarciki dongusuz yapalim.
	if(dizi[0]>dizi[1])
	{
		t=dizi[0];
		dizi[0]=dizi[1];
		dizi[1]=t;
	}
	if(dizi[1]>dizi[2])
	{
		t=dizi[1];
		dizi[1]=dizi[2];
		dizi[2]=t;
	}
	if(dizi[0]>dizi[1])
	{
		t=dizi[0];
		dizi[0]=dizi[1];
		dizi[1]=t;
	}
}
