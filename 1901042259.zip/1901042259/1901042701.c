#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#define N 8
#define size 500
enum orientations{

	O1=1,
	O2=2,
	O3=3,
	O4=4,
	O5=5,
	O6=6,
	O7=7,
	O8=8

};

void menu();
void part1();
void my_memset(int *arr);
void generate_hofstadters_sequence (int *arr, int n, int i);
int find_max (int arr[], int index, int max_value);
int sum_array (int arr[]);
double std_array (int arr[], double *mean, int n, int index);
void install_pipes (int visited[N][N], int x, int y, int orientation, int counter);
void part2();
int is_con(int visited[][N], int x, int y);
void go_ahead(int *r, int *c, int orientation);
void go_back(int *r, int *c, int orientation);
void check(int visited[][N], int *counter);
void part3();
char* remove_duplicates (char* str);


int main(){

	menu();

	return 0;
}
void menu(){
	int op;
	do{	

		printf("Welcome to Homework 8, please choose one of the parts to continue\n");
		printf("________________________\n");
		printf("1) Execute Part 1\n");
		printf("2) Execute Part 2\n");
		printf("3) Execute Part 3\n");
		printf("4) Exit\n");
		scanf("%d",&op);
		switch(op){
			case 1:
			part1();
			break;

			case 2:
			part2();
			break;

			case 3:
			part3();
			break;

			case 4:
			printf("Good Bye!\n");
			break;

			default:
			printf("Invalid choice!\n");
			break;

		}
	}while(op!=4);
}
void part1(){
	int array[size],n,sum;
	my_memset(array);
	int i=0,choice,index,max_value;
	double mean;
	double kare;
	double std;
	do{
	printf("Please make your choice:\n _____________________\n\n");
	printf("1) Fill Array\n2) Find Biggest Number\n3) Calculate Sum\n");
	printf("4) Calculate Standart Deviation\n5) Exit\n");
	scanf("%d",&choice);
		
	
		switch(choice){
			case 1:
			printf("Plase enter how many elements you want :");
			scanf("%d",&n);
			generate_hofstadters_sequence(array,n,i);
			i=0;
			while(array[i]!=0){
				printf("%d ",array[i]);
				i++;
			}
			printf("\n");
			break;
			case 2:
			index=n-1;
			max_value=0;
			printf("The biggest element is %d\n",find_max(array,index,max_value));
			break;
			case 3:
			printf("sum is :%d\n",sum_array(array));
			break;
			case 4:
			index=0;
			mean=0.0;
			printf("Standart Deviation of Elements is: %lf\n",std_array(array,&mean,n,index));
			break;
			case 5:
			printf("Exited from part1\n");
			break;
			default:
			printf("Invalid input!\n");

		

		}
	}while(choice != 5);	

	

}
void generate_hofstadters_sequence (int *arr, int n, int i){

	if(i < n){
		if(i == 1 || i == 0){
			arr[i] = 1;
		}
		else{
			arr[i] = arr[i - arr[i-1]] + arr[i - arr[i-2]];
		}
		i++;
		generate_hofstadters_sequence(arr,n,i);
	}
	
}
void my_memset(int *arr){
	int i;
	for(i=0;i<size;i++){
		arr[i]=0;
	}
}
int find_max (int arr[], int index, int max_value){
	if(index == 0){
		return max_value;
	}
	else{
		if(max_value < arr[index]) max_value = arr[index];
		find_max(arr,index-1,max_value);
	}
}
int sum_array (int arr[]){
	
		if(arr[0] != 0){
			return arr[0] + sum_array(arr+1); 
		}				
}
double std_array (int arr[], double *mean, int n, int index){
	double sum=0.0;
	if(index < n){
		*mean+=(double)arr[index]/n;
		sum+= pow(arr[index],2)/n + std_array(arr,mean,n,index+1) -pow(*mean,2)/n ;
		
	}

	if(index==0) return sqrt(sum);

}
void part2(){
	int i,j;
	int visited[N][N];
	

	int r=0,c=0,orientation=0,counter=0;
	for(i=0;i<N;i++){
		for(j=0;j<N;j++){
			visited[i][j]=0;
		}
	}
	
	install_pipes(visited,r,c,orientation,counter);


}
void install_pipes(int visited[][N], int r, int c, int orientation, int counter){
	int temp;
	temp=is_con(visited,r,c);
	if(temp==0){
		
		go_back(&r,&c,orientation);
		orientation=visited[r][c];

	}
	else{

		orientation=temp;
		visited[r][c]=orientation;
		go_ahead(&r,&c,orientation);
		
	}
	
	check(visited,&counter);		
	if(counter<10) install_pipes(visited,r,c,orientation,counter);
	printf("O%d ",visited[r][c]);



}
int is_con(int visited[][N], int r, int c){
		int i=O1,ori=0,flag;
	
			switch(i){

			case O1:
			flag=(visited[r][c] == 0 || visited[r][c] != O1); //should be free or not same way 
			if(r+2<N && r+2>=0 && c+1<N && c+1>=0 && flag){ // should be in frame 
				ori=O1;
			}
		
	
			case O2:
			flag=(visited[r][c] == 0 || visited[r][c] != O2);
			if(r+1<N && r+1>=0 && c-2<N && c-2>=0 && flag){
				ori=O2;
			}
		
		
			case O3:
			flag=(visited[r][c] == 0 || visited[r][c] != O3);
			if(r-2<N && r-2>=0 && c-1<N && c-1 >=0 && flag){
				ori=O3;
			}

			case O4:
			flag=(visited[r][c] == 0 || visited[r][c] != O4);
			if(r-1<N && r-1>=0 && c+2<N && c+2 >=0 && flag){
				ori=O4;
			}

			case O5:
			flag=(visited[r][c] == 0 || visited[r][c] != O5);
			if(r+1<N && r+1>=0 && c+2<N && c+2 >=0 && flag){
				ori=O5;
			}
	
			case O6:
			flag=(visited[r][c] == 0 || visited[r][c] != O6);
			if(r+2<N && r+2>=0 && c-1<N && c-1 >=0 && flag){
				ori=O6;
			}
	
	
			case O7:
			flag=(visited[r-1][c-2] == 0 || visited[r][c] != O7); 
			if(r-1<N && r-1>=0 && c-2<N && c-2 >=0 && flag){
				ori=O7;
			}
	
		
			case O8:
			flag=(visited[r-2][c+1] == 0 || visited[r][c] != O8);
			if(r-2<N && r-2>=0 && c+1<N && c+1 >=0 && flag){
				ori=O8;

			}
		
			
			}
		
	
		return ori;

}
void go_ahead(int *r, int *c, int orientation){
	switch(orientation){
		case O1:
		*r+=2;
		*c+=1;
		break;
		
		case O2:
		*r+=1;
		*c+=-2;
		break;
		
		case O3:
		*r+=-2;
		*c+=-1;
		break;
		
		case O4:
		*r+=-1;
		*c+=2;
		break;
		
		case O5:
		*r+=1;
		*c+=2;
		break;
		
		case O6:
		*r+=2;
		*c+=-1;
		break;

		case O7:
		*r+=-1;
		*c+=-2;
		break;

		case O8:
		*r+=-2;
		*c+=1;
		break;
	
		}
}
void go_back(int *r, int *c, int orientation){
	switch(orientation){
		case O1:
		*r+=-2;
		*c+=-1;
		break;
		
		case O2:
		*r+=-1;
		*c+=2;
		break;
		
		case O3:
		*r+=2;
		*c+=1;
		break;
		
		case O4:
		*r+=1;
		*c+=-2;
		break;
		
		case O5:
		*r+=-1;
		*c+=-2;
		break;
		
		case O6:
		*r+=-2;
		*c+=1;
		break;

		case O7:
		*r+=1;
		*c+=2;
		break;

		case O8:
		*r+=2;
		*c+=-1;
		break;
	
		}

}
void check(int visited[][N], int *counter){
	int flag = 1,i,j;
		for(i=0;i<N;i++){
			for(j=0;j<N;j++){
				if(visited[i][j]==0){
					flag=0;
					break;
				}
			}
		}
		if(flag) *counter++;
}
void part3(){
	char str[100];
	printf("Please enter a string: ");
	scanf(" %[^\n]s",str);
	remove_duplicates(str);
	printf("Duplicated character has deleted. New string is : %s\n",str);

}

char* remove_duplicates (char* str){
	// untill see null character shifting array
	if(str[0]!='\0'){

		if(str[0]==str[1]){
			// copy one shifted string to one step back
			strcpy(str,str+1);
			str--;
		}
			
	remove_duplicates(str+1);

	}

}
